﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Web_QuanLyThuChi.Controllers
{
    public class TienIchController : Controller
    {
        public ActionResult IndexTroGiup()
        {
            return View();
        }

        public ActionResult PhanHoi()
        {
            return View();
        }


    }
}