﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Web_QuanLyThuChi.Sessions
{
    public class Ses_Admin
    {
        public static string Admin = "Admin";
        public static string DisplayName = "TenHienThi";
    }
}